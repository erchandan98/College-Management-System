/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package config;

/**
 *
 * @author chandan
 */
public class configuration {
    public static final String DRIVER_NAME = "com.mysql.jdbc.Driver";
    public static final String DB_URL = "jdbc:mysql://localhost:3306/CollegeManagmentSystem";
    public static final String DB_USER = "root";
    public static final String DB_PASSWORD = "admin";
}
