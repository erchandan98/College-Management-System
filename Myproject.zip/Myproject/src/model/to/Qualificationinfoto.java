/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.to;

/**
 *
 * @author chandan
 */
public class Qualificationinfoto {
    private String Qid;
    private String Qname;

    public String getQid() {
        return Qid;
    }

    public void setQid(String Qid) {
        this.Qid = Qid;
    }

    public String getQname() {
        return Qname;
    }

    public void setQname(String Qname) {
        this.Qname = Qname;
    }
    
     public String toString(){
        return Qid;
    }
}
