/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.to;

import java.sql.Timestamp;

/**
 *
 * @author chandan
 */
public class logininfoto {
      private String Username;
    private String Password;
    private String Rollno;
    private Timestamp LastLogin;

    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public String getRollno() {
        return Rollno;
    }

    public void setRollno(String Rollno) {
        this.Rollno = Rollno;
    }

    public Timestamp getLastLogin() {
        return LastLogin;
    }

    public void setLastLogin(Timestamp LastLogin) {
        this.LastLogin = LastLogin;
    }
}
