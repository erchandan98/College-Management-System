/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.to;

/**
 *
 * @author chandan
 */
public class branchinfoto {
    private String branchid;
    private String branchname;
    private int totalyear;

    public String getBranchid() {
        return branchid;
    }

    public void setBranchid(String branchid) {
        this.branchid = branchid;
    }

    public String getBranchname() {
        return branchname;
    }

    public void setBranchname(String branchname) {
        this.branchname = branchname;
    }

    public int getTotalyear() {
        return totalyear;
    }

    public void setTotalyear(int totalyear) {
        this.totalyear = totalyear;
    }
    
    public String toString(){
        return branchid ;
    }
}
