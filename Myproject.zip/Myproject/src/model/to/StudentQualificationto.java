/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.to;

/**
 *
 * @author chandan
 */
public class StudentQualificationto {
    private int SQID;
    private int studentid;
    private String QID;
    private float percentage;
    private int passingyear;

    public int getSQID() {
        return SQID;
    }

    public void setSQID(int SQID) {
        this.SQID = SQID;
    }

    public int getStudentid() {
        return studentid;
    }

    public void setStudentid(int studentid) {
        this.studentid = studentid;
    }

    public String getQID() {
        return QID;
    }

    public void setQID(String QID) {
        this.QID = QID;
    }

    public float getPercentage() {
        return percentage;
    }

    public void setPercentage(float percentage) {
        this.percentage = percentage;
    }

    public int getPassingyear() {
        return passingyear;
    }

    public void setPassingyear(int passingyear) {
        this.passingyear = passingyear;
    }
    
     public String toString(){
        return QID;
    }
}
