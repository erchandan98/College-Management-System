/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.to.StudentQualificationto;
import utility.ErrorHandling;

/**
 *
 * @author chandan
 */
public class StudentQualificationDAO {
    private String errormessage;
    
    
    public String getErrormessage(){
        return errormessage;
    }
    
     public boolean insertRecord(StudentQualificationto record){
        try{
            String query = "insert into studentqualification ";
            query += " (SQID , studentid , QID , percentage , passingyear ) ";
            query += " values(?,?,?,?,?)";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setInt(1, record.getSQID());
            stmt.setInt(2, record.getStudentid());
            stmt.setString(3, record.getQID());
            stmt.setFloat(4, record.getPercentage());
            stmt.setInt(5, record.getPassingyear());
            boolean result = stmt.executeUpdate() > 0;
            stmt.close();
            return result;
        }catch(Exception ex){
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return false;
        }
    }
    
     public boolean updateRecord(StudentQualificationto record){
        try{
            String query = "update studentinfoto ";
            query += " Set studentid = ?, QID = ?, percentage = ?, passingyear = ?  ";
            query += " where SQID = ?";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setInt(1, record.getStudentid());
            stmt.setString(2, record.getQID());
            stmt.setFloat(3, record.getPercentage());
            stmt.setInt(4,record.getPassingyear());
            stmt.setInt(5,record.getSQID());
            boolean result = stmt.executeUpdate() > 0;
            stmt.close();
            return result;
        }catch(Exception ex){
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return false;
        }
    }
     
      public boolean deletetRecord(String SQID){
        try{
            String query = "delete from studentqualification ";
            query += " where SQID = ?";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setString(1,SQID);
            boolean result = stmt.executeUpdate() > 0;
            stmt.close();
            return result;
        }catch(Exception ex){
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return false;
        }
    }
      
        public StudentQualificationto getRecord(String SQID){
        try{
            String query = "Select studentid , QID , percentage , passingyear ";
            query += " from Studentqualification ";
            query += " where SQID = ?";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setString(1,SQID);
            StudentQualificationto result = null;
            ResultSet rs = stmt.executeQuery();
            if(rs.next()){
                result = new StudentQualificationto();
                result.setSQID(rs.getInt("SQID"));
                result.setStudentid(rs.getInt("studentid"));
                result.setQID(rs.getString("QID"));
                result.setPercentage((int) rs.getFloat("percentage"));
                result.setPassingyear(rs.getInt("passingyear"));
            }
            stmt.close();
            return result;
        }catch(Exception ex){
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return null;
        }
    }
        
          public boolean deleteRecord(String SQID){
        try{
            String query = "delete from studentqualification ";
            query += " where SQID = ?";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setString(1,SQID);
            boolean result = stmt.executeUpdate() > 0;
            stmt.close();
            return result;
        }catch(Exception ex){
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return false;
        }
    }
      
        public List<StudentQualificationto> getAllRecord(){
        try{
            String query = "Select SQID , studentid , QID , percentage , passingyear " ;
            query += " from Studentqualification ";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            List<StudentQualificationto> result = null;
           ResultSet rs = stmt.executeQuery();
            if(rs.next()){
                result = new ArrayList<>();
                do{
                StudentQualificationto res = new StudentQualificationto();
                res.setStudentid(rs.getInt("Studentid"));
                res.setSQID(rs.getInt("SQID"));
                res.setQID(rs.getString("QID"));
                res.setPercentage((int) rs.getFloat("percentage"));
                res.setPassingyear(rs.getInt("passingyear"));
                result.add(res);
                }while (rs.next());
            }
            stmt.close();
            return result;
        }catch(Exception ex){
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return null;
        }
    }
}
