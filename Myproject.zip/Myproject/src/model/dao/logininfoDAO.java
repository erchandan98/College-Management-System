/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.to.logininfoto;
import utility.ErrorHandling;

/**
 *
 * @author chandan
 */
public class logininfoDAO {
     private String errormessage;

    public String getErrormessage() {
        return errormessage;
    }

    public boolean insertRecord(logininfoto record) {
        try {
            String query = "insert into logininfo ";
            query += " (username,password,rollno,lastlogin) ";
            query += " values(?,?,?,null)";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setString(1, record.getUsername());
            stmt.setString(2, record.getPassword());
            stmt.setString(3, record.getRollno());
            boolean result = stmt.executeUpdate() > 0;
            stmt.close();
            return result;
        } catch (Exception ex) {
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return false;
        }
    }

    public boolean updateRecord(logininfoto record) {
        try {
            String query = "update logininfo ";
            query += " set password=?,rollno=?,lastlogin=? ";
            query += " where username = ?";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setString(1, record.getPassword());
            stmt.setString(2, record.getRollno());
            stmt.setTimestamp(3, record.getLastLogin());
            stmt.setString(4, record.getUsername());
            boolean result = stmt.executeUpdate() > 0;
            stmt.close();
            return result;
        } catch (Exception ex) {
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return false;
        }
    }

    public boolean deleteRecord(String username) {
        try {
            String query = "delete from logininfo ";
            query += " where username = ?";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setString(1, username);
            boolean result = stmt.executeUpdate() > 0;
            stmt.close();
            return result;
        } catch (Exception ex) {
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return false;
        }
    }

    public logininfoto getRecord(String username) {
        try {
            String query = "select username , password , rollno , lastlogin ";
            query += " from logininfo ";
            query += " where username = ?";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setString(1, username);
            logininfoto result = null;
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                result = new logininfoto();
                result.setUsername(rs.getString("username"));
                result.setPassword(rs.getString("password"));
                result.setRollno(rs.getString("rollno"));
                result.setLastLogin(rs.getTimestamp("lastlogin"));
            }
            rs.close();
            stmt.close();
            return result;
        } catch (Exception ex) {
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return null;
        }
    }

    public List<logininfoto> getAllRecord() {
        try {
            String query = "select username , password , rollno , lastlogin ";
            query += " from logininfo ";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            List<logininfoto> result = null;
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                result = new ArrayList<>();
                do {
                    logininfoto res = new logininfoto();
                    res.setUsername(rs.getString("username"));
                    res.setPassword(rs.getString("password"));
                    res.setRollno(rs.getString("rollno"));
                    res.setLastLogin(rs.getTimestamp("lastlogin"));
                    result.add(res);
                } while (rs.next());
            }
            rs.close();
            stmt.close();
            return result;
        } catch (Exception ex) {
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return null;
        }
    }
}
