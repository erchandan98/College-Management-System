/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import utility.ErrorHandling;
import model.to.branchinfoto;
import java.sql.ResultSet;

/**
 *
 * @author chandan
 */
public class branchinfoDAO {
     private String errormessage;

    public String getErrormessage() {
        return errormessage;
    }
    
    public boolean insertRecord(branchinfoto record){
        try{
            String query = "insert into BranchInfo ";
            query += " (branchid,branchname,totalyear ) ";
            query += " values(?,?,?)";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setString(1, record.getBranchid());
            stmt.setString(2, record.getBranchname());
            stmt.setInt(3, record.getTotalyear());
            boolean result = stmt.executeUpdate() > 0;
            stmt.close();
            return result;
        }catch(Exception ex){
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return false;
        }
    }
    
    public boolean updatetRecord(branchinfoto record){
        try{
            String query = "update branchinfo ";
            query += " Set branchname = ?,totalyear = ? ";
            query += " where branchid = ?";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setString(1, record.getBranchname());
            stmt.setInt(2, record.getTotalyear());
            stmt.setString(3, record.getBranchid());
            boolean result = stmt.executeUpdate() > 0;
            stmt.close();
            return result;
        }catch(Exception ex){
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return false;
        }
    }
    
     public boolean deletetRecord(String branchid){
        try{
            String query = "delete from branchinfo ";
            query += " where branchid = ?";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setString(1,branchid);
            boolean result = stmt.executeUpdate() > 0;
            stmt.close();
            return result;
        }catch(Exception ex){
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return false;
        }
    }
     
      public branchinfoto getRecord(String Branchid){
        try{
            String query = "select branchid , branchname , totalyear";
            query += " from branchinfo ";
            query += " where branchid = ?";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setString(1,Branchid);
            branchinfoto result = null;
            ResultSet rs = stmt.executeQuery();
            if(rs.next()){
                result = new branchinfoto();
                result.setBranchid(rs.getString("branchid"));
                result.setBranchname(rs.getString("branchname"));
                result.setTotalyear(rs.getInt("totalyear"));
            }
            stmt.close();
            return result;
        }catch(Exception ex){
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return null;
        }
    }
      
      
          public boolean deleteRecord(String Branchid){
        try{
            String query = "delete from branchinfo ";
            query += " where Branchid = ?";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setString(1,Branchid);
            boolean result = stmt.executeUpdate() > 0;
            stmt.close();
            return result;
        }catch(Exception ex){
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return false;
        }
    }
      
        public List<branchinfoto> getAllRecord(){
        try{
            String query = "select branchid , branchname , totalyear ";
            query += " from branchinfo ";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            List<branchinfoto> result = null;
           ResultSet rs = stmt.executeQuery();
            if(rs.next()){
                result = new ArrayList<>();
                do{
                branchinfoto res = new branchinfoto();
                res.setBranchid(rs.getString("branchid"));
                res.setBranchname(rs.getString("branchname"));
                res.setTotalyear(rs.getInt("totalyear"));
                result.add(res);
                }while (rs.next());
            }
            stmt.close();
            return result;
        }catch(Exception ex){
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return null;
        }
    }
}
