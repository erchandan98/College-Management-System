/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.to.Qualificationinfoto;
import utility.ErrorHandling;

/**
 *
 * @author chandan
 */
public class QualificationinfoDAO {
     private String errormessage;

    public String getErrormessage() {
        return errormessage;
    }

    public boolean insertRecord(Qualificationinfoto record) {
        try {
            String query = "insert into Qualificationinfo ";
            query += " (Qid , Qname) ";
            query += " values(?,?)";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setString(1, record.getQid());
            stmt.setString(2, record.getQname());
            boolean result = stmt.executeUpdate() > 0;
            stmt.close();
            return result;
        } catch (Exception ex) {
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return false;
        }
    }
    
     public boolean updateRecord(Qualificationinfoto record) {
        try {
            String query = "update Qualificationinfo ";
            query += " set Qname=? ";
            query += " where Qid = ?";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setString(1, record.getQid());
            stmt.setString(2, record.getQname());
            boolean result = stmt.executeUpdate() > 0;
            stmt.close();
            return result;
        } catch (Exception ex) {
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return false;
        }
    }
     
     public boolean deleteRecord(String Qid) {
        try {
            String query = "delete from Qualificationinfo ";
            query += " where Qid = ?";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setString(1, Qid);
            boolean result = stmt.executeUpdate() > 0;
            stmt.close();
            return result;
        } catch (Exception ex) {
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return false;
        }
    }
     
     public Qualificationinfoto getRecord(String Qid) {
        try {
            String query = "select Qid , Qname ";
            query += " from Qualificationinfo ";
            query += " where Qid = ?";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setString(1, Qid);
            Qualificationinfoto result = null;
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                result = new Qualificationinfoto();
                result.setQid(rs.getString("Qid"));
                result.setQname(rs.getString("Qname"));
            }
            rs.close();
            stmt.close();
            return result;
        } catch (Exception ex) {
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return null;
        }
    }
     
      public List<Qualificationinfoto> getAllRecord() {
        try {
            String query = "select Qid , Qname ";
            query += " from Qualificationinfo ";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            List<Qualificationinfoto> result = null;
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                result = new ArrayList<>();
                do {
                    Qualificationinfoto res = new Qualificationinfoto();
                    res.setQid(rs.getString("Qid"));
                    res.setQname(rs.getString("Qname"));
                    result.add(res);
                } while (rs.next());
            }
            rs.close();
            stmt.close();
            return result;
        } catch (Exception ex) {
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return null;
        }
    }
}
