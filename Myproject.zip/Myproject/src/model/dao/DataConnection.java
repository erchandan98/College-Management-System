/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import config.configuration;

/**
 *
 * @author chandan
 */
public class DataConnection {
    private static Connection con = null;

    private DataConnection() {
    }

    public static Connection getConnection() throws Exception {
        if (con == null) {
            Class.forName(configuration.DRIVER_NAME);
            con = DriverManager.getConnection(configuration.DB_URL, configuration.DB_USER, configuration.DB_PASSWORD);
        }
        return con;
    }

    public static void closeConnection() throws Exception {
        if (con != null) {
            con.close();
        }
        con = null;
    }
    public static PreparedStatement getPreparedStatement(String query)throws Exception{
        return getConnection().prepareStatement(query);
    }
}
