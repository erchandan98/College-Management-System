/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import utility.ErrorHandling;
import model.to.studentinfoto;
import java.sql.ResultSet;

/**
 *
 * @author chandan
 */
public class studentinfoDAO {
    private String errormessage;
    
    
    public String getErrormessage(){
        return errormessage;
    }
    
     public boolean insertRecord(studentinfoto record){
        try{
            String query = "insert into studentinfo ";
            query += " (studentid , name , fathername , address , contactno , branchid , iscompleted , sessionyear ) ";
            query += " values(?,?,?,?,?,?,?,?)";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setInt(1, record.getStudentid());
            stmt.setString(2, record.getName());
            stmt.setString(3, record.getFathername());
            stmt.setString(4, record.getAddress());
            stmt.setString(5, record.getContactno());
            stmt.setString(6, record.getBranchid());
            stmt.setString(7, record.getIscompleted());
            stmt.setInt(8, record.getSessionyear());
            boolean result = stmt.executeUpdate() > 0;
            stmt.close();
            return result;
        }catch(Exception ex){
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return false;
        }
    }
    
     public boolean updateRecord(studentinfoto record){
        try{
            String query = "update studentinfo ";
            query += " Set name = ?, fathername = ?, address = ?, contactno = ?, branchid = ?, iscompleted = ?, sessionyear = ? ";
            query += " where Studentid = ?";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setString(1, record.getName());
            stmt.setString(2, record.getFathername());
            stmt.setString(3, record.getAddress());
            stmt.setString(4,record.getContactno());
            stmt.setString(5,record.getBranchid());
            stmt.setString(6,record.getIscompleted());
            stmt.setInt(7,record.getSessionyear());
            stmt.setInt(8,record.getStudentid());
            boolean result = stmt.executeUpdate() > 0;
            stmt.close();
            return result;
        }catch(Exception ex){
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return false;
        }
    }
     
      public boolean deletetRecord(String Studentid){
        try{
            String query = "delete from studentinfo ";
            query += " where Studentid = ?";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setString(1,Studentid);
            boolean result = stmt.executeUpdate() > 0;
            stmt.close();
            return result;
        }catch(Exception ex){
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return false;
        }
    }
      
        public studentinfoto getRecord(String Studentid){
        try{
            String query = "select name , fathername , address, contactno, branchid, iscompleted, sessionyear";
            query += " from Studentinfo ";
            query += " where Studentid = ?";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setString(1,Studentid);
            studentinfoto result = null;
            ResultSet rs = stmt.executeQuery();
            if(rs.next()){
                result = new studentinfoto();
                result.setName(rs.getString("Name"));
                result.setFathername(rs.getString("fathername"));
                result.setAddress(rs.getString("Address"));
                result.setContactno(rs.getString("Contactno"));
                result.setBranchid(rs.getString("Branchid"));
                result.setIscompleted(rs.getString("IsCcmpleted"));
                result.setSessionyear(rs.getInt("Sessionyear"));
            }
            stmt.close();
            return result;
        }catch(Exception ex){
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return null;
        }
    }
        
          public boolean deleteRecord(String Studentid){
        try{
            String query = "delete from studentinfo ";
            query += " where Studentid = ?";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setString(1,Studentid);
            boolean result = stmt.executeUpdate() > 0;
            stmt.close();
            return result;
        }catch(Exception ex){
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return false;
        }
    }
      
        public List<studentinfoto> getAllRecord(){
        try{
            String query = "select Studentid, name , fathername , address, Contactno, Branchid, Iscompleted, Sessionyear " ;
            query += " from Studentinfo ";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            List<studentinfoto> result = null;
           ResultSet rs = stmt.executeQuery();
            if(rs.next()){
                result = new ArrayList<>();
                do{
                studentinfoto res = new studentinfoto();
                res.setStudentid(rs.getInt("Studentid"));
                res.setName(rs.getString("Name"));
                res.setFathername(rs.getString("fathername"));
                res.setAddress(rs.getString("Address"));
                res.setContactno(rs.getString("Contactno"));
                res.setBranchid(rs.getString("Branchid"));
                res.setIscompleted(rs.getString("Iscompleted"));
                res.setSessionyear(rs.getInt("Sessionyear"));
                result.add(res);
                }while (rs.next());
            }
            stmt.close();
            return result;
        }catch(Exception ex){
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return null;
        }
    }
}
