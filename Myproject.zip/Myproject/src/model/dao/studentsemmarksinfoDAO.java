/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.to.studentsemmarksinfoto;
import utility.ErrorHandling;

/**
 *
 * @author chandan
 */
public class studentsemmarksinfoDAO {
    private String errormessage;
    
    
    public String getErrormessage(){
        return errormessage;
    }
    
     public boolean insertRecord(studentsemmarksinfoto record){
        try{
            String query = "insert into studentsemmarksinfo ";
            query += " (SMID , semno , studentid , sempercentage , backlog ) ";
            query += " values(?,?,?,?,?)";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setInt(1, record.getSMID());
            stmt.setInt(2, record.getSemno());
            stmt.setInt(3, record.getStudentid());
            stmt.setFloat(4, record.getSempercentage());
            stmt.setInt(5, record.getBacklog());
            boolean result = stmt.executeUpdate() > 0;
            stmt.close();
            return result;
        }catch(Exception ex){
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return false;
        }
    }
    
     public boolean updateRecord(studentsemmarksinfoto record){
        try{
            String query = "update studentsemmarksinfo ";
            query += " Set semno = ?, studentid = ?, sempercentage = ?, backlog = ?  ";
            query += " where SMID = ?";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setInt(1, record.getSemno());
            stmt.setInt(2, record.getStudentid());
            stmt.setFloat(3, record.getSempercentage());
            stmt.setInt(4,record.getBacklog());
            stmt.setInt(5,record.getSMID());
            boolean result = stmt.executeUpdate() > 0;
            stmt.close();
            return result;
        }catch(Exception ex){
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return false;
        }
    }
     
      public boolean deletetRecord(String SMID){
        try{
            String query = "delete from studentsemmarksinfo ";
            query += " where SMID = ?";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setString(1,SMID);
            boolean result = stmt.executeUpdate() > 0;
            stmt.close();
            return result;
        }catch(Exception ex){
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return false;
        }
    }
      
        public studentsemmarksinfoto getRecord(String SMID){
        try{
            String query = "Select semno , studentid , sempercentage , backlog ";
            query += " from studentsemmarksinfo ";
            query += " where SMID = ?";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setString(1,SMID);
            studentsemmarksinfoto result = null;
            ResultSet rs = stmt.executeQuery();
            if(rs.next()){
                result = new studentsemmarksinfoto();
                result.setSemno(rs.getInt("semno"));
                result.setStudentid(rs.getInt("studentid"));
                result.setSMID(rs.getInt("SMID"));
                result.setSempercentage( rs.getInt("sempercentage"));
                result.setBacklog(rs.getInt("backlog"));
            }
            stmt.close();
            return result;
        }catch(Exception ex){
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return null;
        }
    }
        
          public boolean deleteRecord(String SMID){
        try{
            String query = "delete from studentsemmarksinfo ";
            query += " where SMID = ?";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            stmt.setString(1,SMID);
            boolean result = stmt.executeUpdate() > 0;
            stmt.close();
            return result;
        }catch(Exception ex){
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return false;
        }
    }
      
        public List<studentsemmarksinfoto> getAllRecord(){
        try{
            String query = "Select SMID , semno , studentid , sempercentage , backlog " ;
            query += " from studentsemmarksinfo ";
            PreparedStatement stmt = DataConnection.getPreparedStatement(query);
            List<studentsemmarksinfoto> result = null;
           ResultSet rs = stmt.executeQuery();
            if(rs.next()){
                result = new ArrayList<>();
                do{
                studentsemmarksinfoto res = new studentsemmarksinfoto();
                res.setBacklog(rs.getInt("backlog"));
                res.setSMID(rs.getInt("SMID"));
                res.setSemno(rs.getInt("semno"));
                res.setSempercentage( rs.getInt("sempercentage"));
                res.setStudentid(rs.getInt("studentid"));
                result.add(res);
                }while (rs.next());
            }
            stmt.close();
            return result;
        }catch(Exception ex){
            errormessage = ex.toString();
            ErrorHandling.handleException(ex);
            return null;
        }
    }
}
